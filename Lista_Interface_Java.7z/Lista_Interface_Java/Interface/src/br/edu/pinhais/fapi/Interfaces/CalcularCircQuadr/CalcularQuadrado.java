package br.edu.pinhais.fapi.Interfaces.CalcularCircQuadr;

public interface CalcularQuadrado {
	
	int calcularQuadradoPerimetro(int alturaQuadrado);
	//int calcularCirculoPerimetro(int raioCirculo);
	int calcularQuadradoArea(int alturaQuadrado);
	//int calcularCirculoArea(int raioCirculo);	

}
