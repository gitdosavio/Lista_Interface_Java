package br.edu.pinhais.fapi.Interfaces.CalcularCircQuadr;

public interface CalcularCirculo {
	
	//int calcularQuadradoPerimetro(int alturaQuadrado);
	double calcularCirculoPerimetro(double raioCirculo);
	//int calcularQuadradoArea(int alturaQuadrado);
	double calcularCirculoArea(double raioCirculo);	

}
